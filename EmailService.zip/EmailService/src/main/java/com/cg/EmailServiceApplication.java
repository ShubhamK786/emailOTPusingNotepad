package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@SpringBootApplication
public class EmailServiceApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(EmailServiceApplication.class);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(EmailServiceApplication.class, args);
	}
	
	@Bean
	public InternalResourceViewResolver getInternalResourceViewResolver() {
		InternalResourceViewResolver ref = new InternalResourceViewResolver();
		ref.setPrefix("/WEB-INF/jsp/");
		ref.setSuffix(".jsp");
		ref.setViewClass(JstlView.class);
		return ref;
	}

}
