package com.cg.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Customer;
import com.cg.service.EmailServ;
import com.cg.service.ServiceImpl;


@Controller
public class HomeController {
	@Autowired
	EmailServ serv;
	
	@Autowired
	ServiceImpl servImpl;
	
	@RequestMapping(value = "/")
	public String index() {
		return "index";
	}
	
	@RequestMapping(value = "/xyz")
	public String indexAfterSignUp(@RequestParam("otp") String otp) throws IOException {
		if(servImpl.validateOTP(otp)){
			return "index";			
		}
		return "otpForm";
	}
	
	@RequestMapping(value = "/customer-register")
	public String customer_registration() {
		return "customer-register";
	}
	
	@RequestMapping(value = "/customer-login")
	public String customer_login() {
		return "customer-login";
	}
	
	
	@RequestMapping(value = "/forgotPassword")
	public String forgotPassword(Model mv) throws IOException {
		String otp = servImpl.otpGenerate();
		mv.addAttribute("otp", otp);
		return "forgotPassword";
	}
	
	@RequestMapping(value = "/passwordUpdated")
	public String updatePassword(@RequestParam("mobile") String mobile, @RequestParam("password") String password) throws IOException {
		
		return "passwordUpdated";
	}
	
	@RequestMapping(value = "/otpForm")
	public String otpForm(Customer customer) throws IOException {
		servImpl.otpGenerate();
		serv.save(customer);
		return "otpForm";			
	}
}
