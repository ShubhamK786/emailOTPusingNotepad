package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.bean.Customer;

@Repository
@Transactional
public interface EmailServ extends CrudRepository<Customer, Integer>{
	
}
